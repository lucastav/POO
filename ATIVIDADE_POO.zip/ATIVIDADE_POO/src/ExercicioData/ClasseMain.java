package ExercicioData;

public class ClasseMain {

    public static void main(String[] args) {

        Data dt = new Data(25,06, 1994);
                     
        Pessoa p = new Pessoa("Lucas Tavares", dt);
        p.imprime();
    }

}
