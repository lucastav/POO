
package ExercicioData;

public class Pessoa {
    protected String nome;
    public Data dataNasc;
    
    public Pessoa(String n, Data dtNasc){
           nome = n;
           dataNasc = dtNasc;
    } 
    
    public void imprime(){
        System.out.println("O nome é: "+nome);
        System.out.println("A data de nascimento é: ");
        dataNasc.mostrarDados();
    }
}

  