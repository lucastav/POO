package ExercicioData;

public class Data {

    private int d;
    private int m;
    private int a;

    public Data() {
    }

    public Data(int dia, int mes, int ano) {

        d = dia;
        m = mes;
        a = ano;

    }

    public void mostrarDados() {
         System.out.println(""+getD()+"/"+getM()+"/"+getA());
    }

    /**
     * @return the d
     */
    public int getD() {
        return d;
    }

    /**
     * @param d the d to set
     */
    public void setD(int d) {
        this.d = d;
    }

    /**
     * @return the m
     */
    public int getM() {
        return m;
    }

    /**
     * @param m the m to set
     */
    public void setM(int m) {
        this.m = m;
    }

    /**
     * @return the a
     */
    public int getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setA(int a) {
        this.a = a;
    }
}
