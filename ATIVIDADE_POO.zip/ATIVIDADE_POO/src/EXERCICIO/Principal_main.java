package EXERCICIO;

public class Principal_main {
    public static void main(String[] args) {
    
    
    
        Circulo c = new Circulo();        
        
        
        System.out.println(c.calcDiametro());
        System.out.println(c.calcArea());
        System.out.println(c.calcPerimetro());
        
            c.nome();
            c.inicializar();
            c.exibir();
            
            
            
    }
}